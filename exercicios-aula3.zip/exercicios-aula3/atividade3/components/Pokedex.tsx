import React, { useEffect, useState } from 'react';
import '../styles/Pokedex.css';
import { PokeCard } from './PokeCard';

interface Pokemon {
  name: string;
  height: number;
  weight: number;
  types: string[];
  imageUrl: string;
}

// Mensagens
const motivationalMessages = [
  "🌟 Que tal descobrir um novo Pokémon hoje?",
  "🔥 Vamos caçar alguns Pokémons incríveis!",
  "💫 Cada Pokémon tem uma história única para contar!",
  "⚡ A aventura Pokémon nunca termina!",
  "🌿 Explore o mundo Pokémon com curiosidade!",
  "💧 Mergulhe na diversão da Pokédex!",
  "🎯 Encontre seus Pokémons favoritos!",
  "🌈 Descubra as cores do mundo Pokémon!"
];

export const Pokedex: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [pokemons, setPokemons] = useState<Pokemon[]>([]);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [favoriteCount, setFavoriteCount] = useState(0);
  const [selectedType, setSelectedType] = useState<string>('');
  const [currentMessage, setCurrentMessage] = useState('');

  // efeito para monitorar mudanças na lista de pokémons
  useEffect(() => {
    if (pokemons.length > 0) {
      const lastPokemon = pokemons[pokemons.length - 1];
      console.log(`Pokémon ${lastPokemon.name} carregado com sucesso!`);
    }
  }, [pokemons]);

  // efeito para atualizar mensagem motivacional
  useEffect(() => {
    const updateMessage = () => {
      const randomIndex = Math.floor(Math.random() * motivationalMessages.length);
      setCurrentMessage(motivationalMessages[randomIndex]);
    };

    updateMessage();
    const interval = setInterval(updateMessage, 10000); // Muda a cada 10 segundos

    return () => clearInterval(interval);
  }, []);

  // efeito para contar favoritos
  useEffect(() => {
    const countFavorites = () => {
      let count = 0;
      pokemons.forEach(pokemon => {
        const favoriteState = localStorage.getItem(`favorite_${pokemon.name}`);
        if (favoriteState === 'true') {
          count++;
        }
      });
      setFavoriteCount(count);
    };

    countFavorites();
  }, [pokemons]);

  const fetchPokemon = async (name: string) => {
    setIsLoading(true);
    setError('');
    
    try {
      const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${name.toLowerCase()}`);
      if (!response.ok) {
        throw new Error('Pokémon não encontrado');
      }
      const data = await response.json();
      
      const pokemon: Pokemon = {
        name: data.name,
        height: data.height,
        weight: data.weight,
        types: data.types.map((type: any) => type.type.name),
        imageUrl: data.sprites.front_default,
      };

      setPokemons(prev => [...prev, pokemon]);
    } catch (err) {
      setError('Pokémon não encontrado! Verifique o nome e tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearch = () => {
    if (searchTerm.trim()) {
      fetchPokemon(searchTerm.trim());
      setSearchTerm('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const handleFavoriteToggle = (isFavorite: boolean) => {
    setFavoriteCount(prev => isFavorite ? prev + 1 : prev - 1);
  };

  const clearAllPokemons = () => {
    setPokemons([]);
    setFavoriteCount(0);
  };

  const getFilteredPokemons = () => {
    if (!selectedType) return pokemons;
    return pokemons.filter(pokemon => pokemon.types.includes(selectedType));
  };

  const getAllTypes = () => {
    const types = new Set<string>();
    pokemons.forEach(pokemon => {
      pokemon.types.forEach(type => types.add(type));
    });
    return Array.from(types).sort();
  };

  return (
    <div className="pokedex-container">
      <div className="pokedex-header">
        <h1 className="pokedex-title">🌟 Pokédex Personalizada</h1>
        <p className="pokedex-subtitle">{currentMessage}</p>
        
        <div className="pokedex-stats">
          <div className="stat-item">
            <span className="stat-icon">📊</span>
            <span className="stat-label">Total:</span>
            <span className="stat-value">{pokemons.length}</span>
          </div>
          <div className="stat-item">
            <span className="stat-icon">❤️</span>
            <span className="stat-label">Favoritos:</span>
            <span className="stat-value">{favoriteCount}</span>
          </div>
        </div>
      </div>
      
      <div className="pokedex-controls">
        <div className="pokedex-search-container">
          <input
            className="pokedex-input"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Digite o nome do Pokémon..."
            disabled={isLoading}
          />
          <button 
            className={`pokedex-search-button ${isLoading ? 'loading' : ''}`}
            onClick={handleSearch}
            disabled={isLoading}
          >
            {isLoading ? '🔍 Buscando...' : '🔍 Buscar'}
          </button>
        </div>

        <div className="pokedex-filters">
          <select 
            className="pokedex-type-filter"
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
          >
            <option value="">Todos os tipos</option>
            {getAllTypes().map(type => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
          
          <button 
            className="pokedex-clear-button"
            onClick={clearAllPokemons}
            disabled={pokemons.length === 0}
          >
            🗑️ Limpar Todos
          </button>
        </div>
      </div>

      {error && (
        <div className="pokedex-error">
          <span className="error-icon">⚠️</span>
          {error}
        </div>
      )}

      {pokemons.length === 0 && !isLoading && (
        <div className="pokedex-empty">
          <div className="empty-icon">🎮</div>
          <h3>Nenhum Pokémon encontrado</h3>
          <p>Digite o nome de um Pokémon para começar sua aventura!</p>
        </div>
      )}

      <div className="pokedex-list">
        {getFilteredPokemons().map((pokemon, index) => (
          <PokeCard
            key={`${pokemon.name}-${index}`}
            name={pokemon.name}
            height={pokemon.height}
            weight={pokemon.weight}
            types={pokemon.types}
            imageUrl={pokemon.imageUrl}
            onFavoriteToggle={handleFavoriteToggle}
          />
        ))}
      </div>

      {getFilteredPokemons().length === 0 && pokemons.length > 0 && (
        <div className="pokedex-no-results">
          <p>Nenhum Pokémon encontrado com o tipo selecionado.</p>
        </div>
      )}
    </div>
  );
}; 