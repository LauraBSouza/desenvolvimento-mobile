import React, { useEffect, useState } from 'react';
import '../styles/PokeCard.css';

interface PokeCardProps {
  name: string;
  height: number;
  weight: number;
  types: string[];
  imageUrl: string;
  onFavoriteToggle?: (isFavorite: boolean) => void;
}

// Cores únicas para cada tipo de Pokémon
const typeColors: { [key: string]: string } = {
  normal: '#A8A878',
  fire: '#F08030',
  water: '#6890F0',
  electric: '#F8D030',
  grass: '#78C850',
  ice: '#98D8D8',
  fighting: '#C03028',
  poison: '#A040A0',
  ground: '#E0C068',
  flying: '#A890F0',
  psychic: '#F85888',
  bug: '#A8B820',
  rock: '#B8A038',
  ghost: '#705898',
  dragon: '#7038F8',
  dark: '#705848',
  steel: '#B8B8D0',
  fairy: '#EE99AC'
};

export const PokeCard: React.FC<PokeCardProps> = ({ 
  name, 
  height, 
  weight, 
  types, 
  imageUrl, 
  onFavoriteToggle 
}) => {
  const [isFavorite, setIsFavorite] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [showTooltip, setShowTooltip] = useState(false);

  // carrega estado de favorito do localStorage
  useEffect(() => {
    const loadFavoriteState = () => {
      try {
        const favoriteState = localStorage.getItem(`favorite_${name}`);
        if (favoriteState !== null) {
          setIsFavorite(JSON.parse(favoriteState));
        }
      } catch (error) {
        console.error('Erro ao carregar estado de favorito:', error);
      }
    };

    loadFavoriteState();
  }, [name]);

  // salva estado de favorito no localStorage
  useEffect(() => {
    const saveFavoriteState = () => {
      try {
        localStorage.setItem(`favorite_${name}`, JSON.stringify(isFavorite));
        onFavoriteToggle?.(isFavorite);
      } catch (error) {
        console.error('Erro ao salvar estado de favorito:', error);
      }
    };

    saveFavoriteState();
  }, [isFavorite, name, onFavoriteToggle]);

  const toggleFavorite = () => {
    setIsFavorite(!isFavorite);
  };

  const handleImageLoad = () => {
    setIsLoading(false);
  };

  const getTypeIcon = (type: string) => {
    const icons: { [key: string]: string } = {
      fire: '🔥',
      water: '💧',
      grass: '🌱',
      electric: '⚡',
      ice: '❄️',
      fighting: '👊',
      poison: '☠️',
      ground: '🏔️',
      flying: '🦅',
      psychic: '🧠',
      bug: '🐛',
      rock: '🪨',
      ghost: '👻',
      dragon: '🐉',
      dark: '🌑',
      steel: '⚙️',
      fairy: '🧚',
      normal: '⚪'
    };
    return icons[type] || '⚪';
  };

  return (
    <div 
      className={`poke-card ${isFavorite ? 'favorite' : ''} ${isLoading ? 'loading' : ''}`}
      onMouseEnter={() => setShowTooltip(true)}
      onMouseLeave={() => setShowTooltip(false)}
    >
      {/* Efeito de brilho personalizado */}
      <div className="poke-card-glow"></div>
      
      <div className="poke-card-header">
        <span className="poke-card-name">
          {name}
          {isFavorite && <span className="favorite-star">⭐</span>}
        </span>
        <button 
          className={`poke-card-favorite-button ${isFavorite ? 'favorited' : ''}`}
          onClick={toggleFavorite}
          title={isFavorite ? 'Remover dos favoritos' : 'Adicionar aos favoritos'}
        >
          {isFavorite ? '❤️' : '🤍'}
        </button>
      </div>
      
      <div className="poke-card-image-container">
        {isLoading && (
          <div className="poke-card-loading">
            <div className="loading-spinner"></div>
            <span>Carregando...</span>
          </div>
        )}
        <img 
          src={imageUrl} 
          alt={name}
          className="poke-card-image"
          onLoad={handleImageLoad}
          style={{ opacity: isLoading ? 0 : 1 }}
        />
      </div>
      
      <div className="poke-card-info">
        <div className="poke-card-stats">
          <div className="poke-card-stat">
            <span className="stat-icon">📏</span>
            <span className="stat-label">Altura:</span>
            <span className="stat-value">{(height / 10).toFixed(1)}m</span>
          </div>
          <div className="poke-card-stat">
            <span className="stat-icon">⚖️</span>
            <span className="stat-label">Peso:</span>
            <span className="stat-value">{(weight / 10).toFixed(1)}kg</span>
          </div>
        </div>
        
        <div className="poke-card-types">
          {types.map((type, index) => (
            <span 
              key={index} 
              className="poke-card-type"
              style={{ 
                background: `linear-gradient(135deg, ${typeColors[type]} 0%, ${typeColors[type]}dd 100%)`,
                border: `2px solid ${typeColors[type]}`
              }}
            >
              {getTypeIcon(type)} {type}
            </span>
          ))}
        </div>
      </div>

      {/* Tooltip personalizado */}
      {showTooltip && (
        <div className="poke-card-tooltip">
          <p>Clique no coração para favoritar!</p>
          <p>Tipos: {types.join(', ')}</p>
        </div>
      )}
    </div>
  );
}; 