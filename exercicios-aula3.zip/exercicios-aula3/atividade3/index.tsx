import React from 'react';
import ReactDOM from 'react-dom/client';
import { Pokedex } from './components/Pokedex';
import './styles/PokeCard.css';
import './styles/Pokedex.css';

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

root.render(
  <React.StrictMode>
    <Pokedex />
  </React.StrictMode>
); 