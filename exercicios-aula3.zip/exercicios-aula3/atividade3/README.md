# 🌟 Pokédex Personalizada

Uma Pokédex moderna e interativa desenvolvida com React, TypeScript e CSS personalizado, repleta de funcionalidades únicas e design autoral.

## ✨ Funcionalidades Implementadas

### 🎨 **Design Autoral**
- **Paleta de cores vibrante**: Gradientes únicos com tons de roxo, azul e dourado
- **Efeitos visuais**: Bordas com gradientes animados, efeitos de brilho e sombras dinâmicas
- **Animações suaves**: Transições e hover effects elaborados
- **Padrão de fundo**: Textura sutil com pontos para profundidade visual

### 🔧 **Funcionalidades Avançadas**
- **Sistema de favoritos**: Salva preferências no localStorage com contador em tempo real
- **Filtro por tipo**: Filtra Pokémons por tipo com cores únicas para cada elemento
- **Mensagens motivacionais**: Frases aleatórias que mudam a cada 10 segundos
- **Estados de loading**: Animações de carregamento personalizadas
- **Tooltips informativos**: Dicas visuais ao passar o mouse

### 📊 **Estatísticas em Tempo Real**
- Contador total de Pokémons carregados
- Contador de Pokémons favoritos
- Interface responsiva com estatísticas visuais

### 🎯 **Melhorias de UX**
- **Busca por Enter**: Pressione Enter para buscar
- **Botão de limpar**: Remove todos os Pokémons de uma vez
- **Estados vazios**: Mensagens motivacionais quando não há Pokémons
- **Feedback visual**: Animações de erro e sucesso
- **Responsividade**: Design adaptável para mobile e desktop

## 🛠️ Tecnologias Utilizadas

- **React 18** com TypeScript
- **useState** para gerenciamento de estado
- **useEffect** para efeitos colaterais
- **Props** para comunicação entre componentes
- **CSS Modules** para estilização organizada
- **localStorage** para persistência de dados

## 🎨 Componentes Organizados

### `PokeCard.tsx`
- **Props**: Recebe dados do Pokémon e callback de favoritos
- **Estados**: Loading, favorito, tooltip
- **Funcionalidades**: 
  - Cores únicas por tipo de Pokémon
  - Ícones personalizados para cada elemento
  - Animações de hover e loading
  - Sistema de favoritos com localStorage

### `Pokedex.tsx`
- **Estados**: Lista de Pokémons, filtros, mensagens
- **Funcionalidades**:
  - Busca na API da PokéAPI
  - Filtros por tipo
  - Contadores em tempo real
  - Mensagens motivacionais rotativas

## 🌈 Paleta de Cores por Tipo

Cada tipo de Pokémon tem sua cor única:
- 🔥 **Fire**: #F08030
- 💧 **Water**: #6890F0
- ⚡ **Electric**: #F8D030
- 🌱 **Grass**: #78C850
- ❄️ **Ice**: #98D8D8
- 👊 **Fighting**: #C03028
- ☠️ **Poison**: #A040A0
- 🏔️ **Ground**: #E0C068
- 🦅 **Flying**: #A890F0
- 🧠 **Psychic**: #F85888
- 🐛 **Bug**: #A8B820
- 🪨 **Rock**: #B8A038
- 👻 **Ghost**: #705898
- 🐉 **Dragon**: #7038F8
- 🌑 **Dark**: #705848
- ⚙️ **Steel**: #B8B8D0
- 🧚 **Fairy**: #EE99AC
- ⚪ **Normal**: #A8A878

## 🚀 Como Executar

1. Clone o repositório
2. Instale as dependências: `npm install`
3. Execute o projeto: `npm start`
4. Acesse: `http://localhost:3000`

## 📱 Responsividade

- **Desktop**: Layout em grid com 3+ colunas
- **Tablet**: Layout adaptado com 2 colunas
- **Mobile**: Layout em coluna única com controles otimizados

## 🎯 Melhorias Implementadas

### ✅ **Requisitos Atendidos**
- ✅ Uso de **props** para comunicação entre componentes
- ✅ **useState** para gerenciamento de estado
- ✅ **useEffect** para efeitos colaterais
- ✅ **Estilização separada** em arquivos CSS
- ✅ **Organização de componentes** em arquivos próprios
- ✅ **Código autoral** com design único e funcionalidades extras

### 🌟 **Extras Autorais**
- Sistema de favoritos com persistência
- Filtros por tipo com cores personalizadas
- Mensagens motivacionais rotativas
- Animações e efeitos visuais únicos
- Tooltips informativos
- Estatísticas em tempo real
- Estados de loading personalizados
- Design responsivo e moderno

---

**Desenvolvido com ❤️ e muito carinho para a Pokédex mais autoral possível!** 